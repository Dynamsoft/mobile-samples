//
//  DynamsoftBarcodeSDK.h
//  DynamsoftBarcodeSDK
//
//  Created by Dynamsoft on 2018/6/7.
//  Copyright © 2018 Dynamsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DynamsoftBarcodeSDK.
FOUNDATION_EXPORT double DynamsoftBarcodeSDKVersionNumber;

//! Project version string for DynamsoftBarcodeSDK.
FOUNDATION_EXPORT const unsigned char DynamsoftBarcodeSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DynamsoftBarcodeSDK/PublicHeader.h>

#import <DynamsoftBarcodeReader/DynamsoftBarcodeReader.h>
